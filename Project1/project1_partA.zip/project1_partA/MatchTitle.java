/** MatchTitle class which matches a given review to the most
 * suitable title by using local edit distance
 *
 * Attribution
 *   The partial code for parsing files within directory was referred from
 *   http://stackoverflow.com/questions/31697480/reading-all-text-filesdata-set-from-one-folder-in-java
 *   
 *   The basic code frame of calculating local and global edit distances were referred from
 *   the unimelb lecture note "Approximate Matching COMP90049 Knowledge Technologies 
 *   by Justin Zobel and Rao Kotagiri (CIS)"
 *
 *
 * @ student name :  Tessa(Hyeri) Song
 * @ login id : songt
 * @ student number : 597952
 *
 * @ version 1.0
 */


import java.util.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.FileReader;
import java.io.BufferedReader;
import java.util.StringTokenizer;

public class MatchTitle {

	/** number of film titles */
	public static final int NUM_FILMS = 6930;

	/** store all titles */
	private String[] titleArr;


	/** 
	 * read film_titles.txt 
	 */
	public void readTitles(){
		titleArr = new String[NUM_FILMS];
		FileReader fin;
		
		// open the file stream and put all the film titles in titleArr
		try{
			fin = new FileReader("film_titles.txt");
			BufferedReader in = new BufferedReader(fin);
	    
			for(int i = 0 ; i<NUM_FILMS ; i++){
				titleArr[i] = in.readLine();
			}
			
			// close file stream
			fin.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	

	}
	
	
	/**
	 * match 'numReviews' reviews with titles using local edit distance 
	 */
	public void startMatchWithTitle(int numReviews){
		String target_dir = "./revs";
		int i = 0;
		File dir = new File(target_dir);
		File[] files = dir.listFiles();
		
		for (File f : files) {
			if(i < numReviews ){
				String reviewStr = "";
				String rightTitle = "";
				// read this review as one long string
				try {
					FileReader fin = new FileReader(f);
					BufferedReader in = new BufferedReader(fin);
					reviewStr = in.readLine();
					fin.close();
					
				} catch(Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				//find out the film title for this review
				rightTitle = findTitleByLocal(reviewStr);

				// print out the result for this review
				System.out.println("The film title of this review file(" + f + ") is "
					+ rightTitle+".");

				i++;
				
			}else{
				break;
			}
		}
		
	}
	

	/**
	 * match the given review string with proper title using local edit distance 
	 */
	public String findTitleByLocal(String reviewStr){
		String rightTitle = "";
		int maxLocal = -1;
				
		// find out the most suitable title for this review by iterating titleArr.
		// the title with the biggest local edit distance is chosen
		for(String title : titleArr){
			int local = calculateLocal(title, reviewStr);
			if(local > maxLocal){
				maxLocal = local;
				rightTitle = title;
			}
					
		}
		
		return rightTitle;		
	}
		

	
	
	/**
	 * Calculate local edit distance of String a and b
	 * and return the value
	 * (m, r, i, r) = (1, -1, -1, -1)
	 */
	public int calculateLocal(String a, String b){		
		// get the lengths of the two strings
		int aLen = a.length();
		int bLen = b.length();
		
		// set the double array for storing edit distance values
		int[][] editArray = new int[aLen+1][bLen+1];
		int local = 0;
		
		// initialize the top and left lines with 0
		for(int i = 0; i<=aLen; i++){
			editArray[i][0] = 0;
		}
		
		for(int j = 0; j<=bLen; j++){
			editArray[0][j] = 0;
		}
		
		// fill up the local edit distance array
		for(int i = 1 ; i<=aLen ; i++){
			for(int j = 1 ; j<=bLen ; j++){
				editArray[i][j] = returnMax( 0,
						editArray[i-1][j] - 1, 
						editArray[i][j-1] - 1,
						editArray[i-1][j-1] + isEqual(a.charAt(i-1), b.charAt(j-1))
						);
				
				// update local edit distance 
				if(local < editArray[i][j])
					local = editArray[i][j];
				
			}
			
		}
		
		return local;
		
	}
	
	
	

	/**
	 * return max value among a, b, c and d
	 */
	public int returnMax(int a, int b, int c, int d){
		int tempMax = Math.max(a,b);
		int tempMax2 = Math.max(c,d);
		return Math.max(tempMax, tempMax2);                                      
	
	}
	

	
	/**
	 * check if two character a and b are equal
	 * if they are the same, return 1 otherwise return -1
	 * lower and upper case are considered to be the same
	 */
	public int isEqual(char a, char b){
		if (Character.toUpperCase(a) == Character.toUpperCase(b))
			return 1;
		else
			return -1;
	
	}



}
